<!-- Premium Navigation -->
<nav class="navbar-premium" id="navbar">
    <div class="container">
        <div class="nav-wrapper">
            <!-- Logo -->
            <a href="<?php echo $baseURL ?? '/'; ?>index.php" class="nav-logo">
                <i class="fas fa-globe"></i>
                <span>SITUNEO</span>
            </a>

            <!-- Desktop Menu -->
            <ul class="nav-menu" id="navMenu">
                <li><a href="<?php echo $baseURL ?? '/'; ?>index.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>"><?php echo $t['nav_home'] ?? 'Beranda'; ?></a></li>
                <li><a href="<?php echo $baseURL ?? '/'; ?>about.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'about.php') ? 'active' : ''; ?>"><?php echo $t['nav_about'] ?? 'Tentang'; ?></a></li>
                <li><a href="<?php echo $baseURL ?? '/'; ?>services.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'services.php') ? 'active' : ''; ?>"><?php echo $t['nav_services'] ?? 'Layanan'; ?></a></li>
                <li><a href="<?php echo $baseURL ?? '/'; ?>portfolio.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'portfolio.php') ? 'active' : ''; ?>"><?php echo $t['nav_portfolio'] ?? 'Portfolio'; ?></a></li>
                <li><a href="<?php echo $baseURL ?? '/'; ?>pricing.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'pricing.php') ? 'active' : ''; ?>"><?php echo $t['nav_pricing'] ?? 'Harga'; ?></a></li>
                <li><a href="<?php echo $baseURL ?? '/'; ?>blog.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'blog.php') ? 'active' : ''; ?>"><?php echo $t['nav_blog'] ?? 'Blog'; ?></a></li>
                <li><a href="<?php echo $baseURL ?? '/'; ?>contact.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'contact.php') ? 'active' : ''; ?>"><?php echo $t['nav_contact'] ?? 'Kontak'; ?></a></li>
            </ul>

            <!-- Right Actions -->
            <div class="nav-actions">
                <!-- Language Switcher -->
                <div class="lang-switcher">
                    <button class="lang-btn <?php echo $lang === 'id' ? 'active' : ''; ?>" onclick="switchLanguage('id')">
                        <span class="flag">🇮🇩</span> ID
                    </button>
                    <button class="lang-btn <?php echo $lang === 'en' ? 'active' : ''; ?>" onclick="switchLanguage('en')">
                        <span class="flag">🇺🇸</span> EN
                    </button>
                </div>

                <!-- CTA Button -->
                <a href="<?php echo $baseURL ?? '/'; ?>auth/login.php" class="btn-primary-nav">
                    <i class="fas fa-user"></i>
                    <span><?php echo $t['nav_login'] ?? 'Masuk'; ?></span>
                </a>

                <!-- Mobile Menu Toggle -->
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </div>
</nav>

<!-- NIB Badge (RED gradient with pulse) -->
<div class="nib-badge">
    <div class="nib-badge-content">
        <i class="fas fa-certificate"></i>
        <div class="nib-badge-text">
            <div class="nib-label"><?php echo $t['nib_label'] ?? 'NIB Terdaftar'; ?></div>
            <div class="nib-number">1234567890123</div>
        </div>
    </div>
    <div class="nib-pulse"></div>
</div>

<script>
// Language Switcher Function
function switchLanguage(newLang) {
    const currentUrl = window.location.href;
    const url = new URL(currentUrl);
    url.searchParams.set('lang', newLang);
    window.location.href = url.toString();
}

// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const navMenu = document.getElementById('navMenu');

    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navMenu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
    }

    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        const navbar = document.querySelector('.navbar-premium');
        if (!navbar.contains(event.target) && navMenu.classList.contains('active')) {
            mobileMenuToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
        }
    });
});
</script>
