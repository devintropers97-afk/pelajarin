# SITUNEO DIGITAL - Panduan Instalasi Lengkap

**Version**: Batch 1 + Batch 2 (Complete Package)
**Last Updated**: November 2024
**Status**:  READY FOR CPANEL UPLOAD

---

## =� Isi Package

Package ini berisi **SEMUA FILE** yang dibutuhkan untuk menjalankan SITUNEO DIGITAL:

###  Batch 1 (Database & Core)
- `database/schema-complete.sql` - 95 tabel database
- `database/seed-services.sql` - 232+ layanan dengan dual pricing
- `config/` - Konfigurasi aplikasi (database, app, mail, paths)
- `core/` - Classes inti (Database, Security, Session, Config)

###  Batch 2 Part 1 (Advanced Core)
- `core/Router.php` - Routing system
- `core/Auth.php` - Authentication & authorization
- `core/Validator.php` - Form validation
- `helpers/` - Common, formatting, pricing functions

###  Batch 2 Part 2 (Frontend)
- `index.php` - Main entry point & router
- `.htaccess` - Apache configuration & clean URLs
- `public/index.php` - Homepage dengan dual pricing
- `includes/header/` - Header template
- `includes/footer/` - Footer template
- `assets/css/` - Stylesheet (main.css, responsive.css)
- `assets/js/` - JavaScript (main.js dengan network animation)

---

## =� Cara Install di cPanel

### Step 1: Upload File ke cPanel

1. Login ke **cPanel**
2. Buka **File Manager**
3. Masuk ke folder `public_html` (atau `www`, `htdocs`)
4. **DELETE** semua file lama (jika ada)
5. **Upload** file `situneo-complete.zip`
6. **Klik kanan** pada ZIP � **Extract**
7. **Pindahkan** semua file dari folder hasil extract ke `public_html`
8. **Delete** file ZIP dan folder hasil extract

**STRUKTUR AKHIR harus seperti ini:**
```
public_html/
   index.php
   .htaccess
   config/
   core/
   database/
   helpers/
   includes/
   assets/
   public/
```

---

### Step 2: Buat Database MySQL

1. Di cPanel, buka **MySQL� Databases**

2. **Buat Database Baru:**
   - Database Name: `situneo_digital`
   - Klik **Create Database**

3. **Buat User Database:**
   - Username: `user_situneo_digital`
   - Password: (gunakan password kuat, simpan!)
   - Klik **Create User**

4. **Add User to Database:**
   - User: pilih user yang baru dibuat
   - Database: pilih database yang baru dibuat
   - Klik **Add**
   - Beri **ALL PRIVILEGES**
   - Klik **Make Changes**

5. **Catat informasi ini:**
   ```
   Database Name: (prefix)_situneo_digital
   Username: (prefix)_user_situneo_digital
   Password: (password yang Anda buat)
   Host: localhost
   ```

---

### Step 3: Import Database

1. Di cPanel, buka **phpMyAdmin**
2. Pilih database `(prefix)_situneo_digital`
3. Klik tab **Import**
4. **IMPORT FILE PERTAMA:**
   - Klik **Choose File**
   - Pilih `database/schema-complete.sql`
   - Klik **Go**
   - Tunggu sampai selesai (muncul pesan sukses)

5. **IMPORT FILE KEDUA:**
   - Klik **Choose File**
   - Pilih `database/seed-services.sql`
   - Klik **Go**
   - Tunggu sampai selesai

6. **Verifikasi:**
   - Cek apakah ada **95 tabel**
   - Buka tabel `services` � harus ada **232+ data**
   - Buka tabel `service_categories` � harus ada **10 data**

---

### Step 4: Update Konfigurasi Database

1. Buka **File Manager** � `public_html/config/database.php`
2. Klik **Edit**
3. **Update informasi database:**

```php
// SEBELUM (contoh):
define('DB_HOST', 'localhost');
define('DB_USER', 'nrrskfvk_user_situneo_digital');
define('DB_PASS', 'Devin1922$');
define('DB_NAME', 'nrrskfvk_situneo_digital');

// GANTI DENGAN (sesuaikan dengan database Anda):
define('DB_HOST', 'localhost');
define('DB_USER', '(prefix)_user_situneo_digital');  // Sesuaikan
define('DB_PASS', 'password_anda');                   // Sesuaikan
define('DB_NAME', '(prefix)_situneo_digital');        // Sesuaikan
```

4. **Save Changes**

---

### Step 5: Update Konfigurasi Website

1. Buka **File Manager** � `public_html/config/app.php`
2. Klik **Edit**
3. **Update informasi website:**

```php
// SITE URL - PENTING!
define('SITE_URL', 'https://namadomain.com');  // Ganti dengan domain Anda

// Company Information
define('COMPANY_NAME', 'SITUNEO DIGITAL');
define('COMPANY_EMAIL', 'info@namadomain.com');  // Email Anda
define('COMPANY_WHATSAPP', '6281234567890');      // WhatsApp Anda
define('COMPANY_ADDRESS', 'Alamat perusahaan Anda');
```

4. **Save Changes**

---

### Step 6: Set Permissions (File Permissions)

Di cPanel File Manager, set permissions untuk folder-folder ini:

```
logs/          � 755 (atau 777 jika error)
uploads/       � 755 (atau 777 jika error)
config/        � 755
.htaccess      � 644
```

**Cara set permission:**
1. Klik kanan pada folder/file
2. Pilih **Change Permissions**
3. Centang sesuai angka di atas
4. Klik **Change Permissions**

---

### Step 7: Buat Folder yang Dibutuhkan

Di File Manager, buat folder-folder ini (jika belum ada):

```
public_html/
   uploads/
   logs/
   assets/
       images/
           payment/
```

**Cara buat folder:**
1. Klik **+ Folder**
2. Masukkan nama folder
3. Klik **Create New Folder**

---

##  Testing Website

1. **Buka website Anda:** `https://namadomain.com`

2. **Cek halaman utama:**
   -  Homepage tampil dengan dual pricing
   -  Stats section menampilkan angka (232+, 10, 50)
   -  Network animation berjalan di background
   -  Navbar sticky berfungsi
   -  WhatsApp float button muncul

3. **Test link-link:**
   - `/` - Homepage 
   - `/services` - Halaman layanan (akan dibuat Batch 3)
   - `/pricing` - Halaman harga (akan dibuat Batch 3)
   - `/contact` - Halaman kontak (akan dibuat Batch 3)

4. **Cek database connection:**
   - Jika homepage tampil tanpa error � Database connection OK
   - Jika muncul error database � Cek config/database.php

---

## =' Troubleshooting

### L Error: "500 Internal Server Error"

**Solusi:**
1. Cek `.htaccess` - Pastikan file ada dan readable
2. Cek PHP Version - Minimal PHP 7.4
3. Cek error log di cPanel � Errors
4. Set permission `logs/` menjadi 777

### L Error: "Database connection failed"

**Solusi:**
1. Buka `config/database.php`
2. Pastikan DB_HOST, DB_USER, DB_PASS, DB_NAME benar
3. Cek di phpMyAdmin apakah database dan user sudah dibuat
4. Pastikan user sudah di-add ke database dengan ALL PRIVILEGES

### L Homepage tampil tapi tanpa styling (CSS tidak load)

**Solusi:**
1. Cek URL di browser - pastikan HTTPS
2. Buka `config/app.php` - pastikan SITE_URL benar
3. Buka `config/paths.php` - pastikan ASSETS_URL benar
4. Cek permission folder `assets/` � harus 755

### L Error: "Class not found" atau "Function not defined"

**Solusi:**
1. Buka `config/bootstrap.php`
2. Pastikan semua `require_once` path benar
3. Cek apakah file core/ dan helpers/ sudah ter-upload

### L Network animation tidak jalan

**Solusi:**
1. Buka browser Console (F12)
2. Cek error JavaScript
3. Pastikan file `assets/js/main.js` sudah ter-upload
4. Pastikan Bootstrap JS sudah load (cek footer)

---

## =� Checklist Instalasi

Centang setelah selesai:

- [ ] Files uploaded ke public_html
- [ ] Database MySQL dibuat
- [ ] User database dibuat dan di-add
- [ ] schema-complete.sql di-import (95 tabel)
- [ ] seed-services.sql di-import (232+ services)
- [ ] config/database.php di-update
- [ ] config/app.php di-update (SITE_URL, email, WA)
- [ ] Folder logs/ dan uploads/ dibuat
- [ ] Permissions di-set (755/644)
- [ ] Homepage ditest dan berfungsi
- [ ] Database connection OK
- [ ] CSS dan JS load sempurna
- [ ] Network animation berjalan

---

## <� Fitur yang SUDAH Jalan (Batch 1 + 2)

 **Database:**
- 95 tabel siap pakai
- 232+ layanan dengan dual pricing
- 10 kategori layanan
- Seed data lengkap

 **Security:**
- CSRF protection
- XSS filtering
- Password hashing (bcrypt)
- SQL injection prevention
- Rate limiting

 **Frontend:**
- Homepage responsive
- Dual pricing showcase
- Network particle animation
- Counter animation
- Smooth scrolling
- Back to top button
- WhatsApp float button
- Mobile-friendly navbar

 **Core System:**
- Clean URL routing
- Authentication system
- Form validation
- Session management
- Helper functions (80+)

---

## =� Fitur yang BELUM Ada (Akan di Batch 3+)

� **Halaman-halaman:**
- Halaman Services (list 232+ layanan)
- Halaman Pricing (perbandingan harga)
- Halaman Portfolio (50 demo)
- Halaman Contact
- Halaman About
- Login & Register pages

� **Dashboard:**
- Admin panel
- Client dashboard
- Freelancer dashboard

� **Functionality:**
- Order system
- Payment integration
- Email notifications
- File upload
- Search & filter

---

## =� Support

Jika ada masalah saat instalasi:

1. **Cek Error Log:**
   - cPanel � Errors
   - File: `logs/php-error.log`

2. **Browser Console:**
   - Tekan F12
   - Tab Console (untuk JavaScript errors)
   - Tab Network (untuk failed requests)

3. **Common Issues:**
   - 90% masalah = database config salah
   - 5% = file permission
   - 5% = PHP version < 7.4

---

## <� Selamat!

Jika checklist sudah  semua, berarti instalasi **BERHASIL**!

Website Anda sekarang sudah:
-  Database lengkap 95 tabel
-  232+ layanan dengan dual pricing
-  Homepage modern & responsive
-  Security terjamin
-  Siap untuk Batch 3 (halaman-halaman lainnya)

**Next Step:** Tunggu Batch 3 untuk halaman Services, Pricing, Contact, dll.

---

**� 2024 SITUNEO DIGITAL - Made with d in Indonesia**
